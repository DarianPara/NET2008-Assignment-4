DiceRoll: This app simulates the rolling of two dice. It outputs the roll of each individual dice, and their sum. It then asks the user if they would like to roll again, and if the user inputs 'yes' the dice are rolled again. This cycle is repeated until the user inputs 'no' after a roll. **Note: when run through docker, the automatic input is no, therefore only one roll of the die occurs.**

Github repository: https://github.com/DarianPara/NET2008-Assignment-4.git

DockerHub image: https://hub.docker.com/r/darianrp/diceroll

