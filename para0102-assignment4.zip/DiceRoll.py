import random

def roll_two_dice():
    die1 = random.randint(1, 6)
    die2 = random.randint(1, 6)
    total = die1 + die2

    print(f"You rolled: Die 1: {die1}, Die 2: {die2}")
    print(f"Total: {total}")

while True:
    roll_two_dice()

    try:
        roll_again = input("Do you want to roll the dice again? (yes/no): ") or 'no'
    except EOFError:
        roll_again = 'no'

    if roll_again.lower() != 'yes':
        print("Thank you for playing. Goodbye!")
        break

